# Senior Circle Backend
Backend server for global chat app.
